# ANN
This module will use Pybrain as the required package to contructure a Artifical Neural Network to predict Life cycle inventory 
as well as some of the impact value
